#include <stdio.h> //entrada e saida de dados
#include <stdlib.h> //para aloca��o de memoria
#include <string.h>//manipula�ao e processamento de strings

#define MAX 100  //numero maximo de usuarios

typedef struct {//cria a estrutura
    int id;//um id unico para cada pessoa
    char nome[50];//armazena o nome
    int *amigos;   // Lista din�mica de amigos
    int numAmigos; // N�mero de amigos
} Pessoa;

// Fun��o recursiva para verificar se um conjunto de pessoas forma um clique
//um clique � um par de nos conectado por uma amizade, grupo de pessoas onde sao amigos em comum
int eh_clique(Pessoa pessoas[], int clique[], int numero_pessoas_clique, int posicao) {
    if (posicao == numero_pessoas_clique) {//todos os pares foram verificados e sao amigos em comum
        return 1; // Todos os pares foram verificados
    }

    for (int i = posicao + 1; i < numero_pessoas_clique; i++) {//se o clique no indice i for encontrado em clique[posicao]definimos como 1 e finalizamos
        int amigoEncontrado = 0;
        for (int j = 0; j < pessoas[clique[posicao]].numAmigos; j++) {
            if (pessoas[clique[posicao]].amigos[j] == clique[i]) {
                amigoEncontrado = 1;//um amigo foi encontrado na lista de amigos
                break;
            }
        }
        if (!amigoEncontrado) {//indica que nao forma um clique
            return 0;
        }
    }
    return eh_clique(pessoas, clique, numero_pessoas_clique, posicao + 1);
}

// Fun��o para encontrar o maior clique, a maior comunidade conectada
void maior_rede_concetada(Pessoa pessoas[], int n) {//verifica se cada subconjunto � um clique
    int maiorClique[MAX];//array para armazenar o maior clique conectado
    int tamanho_clique = 0;//tamanho do maior clique encontrado
    int subconjuntos[MAX];//array que armazena um subconjunto de pessoas


    //gera os subconjuntos de um conjunto de n pessoas e verifica se forma um clique(n�)
    for (int i = 0; i < (1 << n); i++) {//equivale a 2^n, deslocamento bit a bit
        int clique = 0;
        for (int j = 0; j < n; j++) {//verifica se o j-esimo elemento esta no subconjunto
            if (i & (1 << j)) {
                subconjuntos[clique++] = j;//se o bit estiver definido, o indice � adicionado ao array e clique � incrementado
            }
        }
        if (eh_clique(pessoas, subconjuntos, clique, 0)) {// a cada subconjunto, a fun�ao verifica se formam um clique
            if (clique > tamanho_clique) {
                tamanho_clique = clique;//atualiza o tamanho_clique e o maior clique e tambem atualizado como maior clique
                memcpy(maiorClique, subconjuntos, clique * sizeof(int));
            }
        }
    }
    printf("\n\nSolucao:\n\n");
    printf("Maior comunidade conectada (tamanho %d):\n", tamanho_clique);//verifica todos subconjuntos, e imprime o tamnho do maior clique econtrada(a maior comunidade)
    for (int i = 0; i < tamanho_clique; i++) {// recupera o nome da pessoa no �ndice
        printf("%s ", pessoas[maiorClique[i]].nome);
    }
    printf("\n");
}

int main() {
    Pessoa pessoas[MAX];
    int n, m;  // N�mero de usu�rios e n�mero de amizades

    // Leitura dos dados a partir de um arquivo
    FILE *arquivoDados = fopen("dados.txt", "r");//abrindo o oarquivo no modo de leitura
    if (!arquivoDados) {
        printf("Erro ao abrir o arquivo de dados.\n");
        return 1;
    }

    // Leitura do n�mero de pessoas e n�mero de amizades
    //faz a leitura dos dados a partir de um arquivo
    fscanf(arquivoDados, "\n%d", &n);
    fscanf(arquivoDados, "\n%d", &m);

    // Inicializar as pessoas e ler os nomes do arquivo
    for (int i = 0; i < n; i++) {
        pessoas[i].id = i;
        fgetc(arquivoDados); // Para consumir o newline ap�s o n�mero
        fgets(pessoas[i].nome, sizeof(pessoas[i].nome), arquivoDados);//retorna um ponteiro para o buffer string se bem-sucedido e se retonr NULL deu erro

        //incializa a lista de amigos
        size_t len = strlen(pessoas[i].nome);//retorna o comprimento da string e o len armazena o comprimento da string
        if (len > 0 && pessoas[i].nome[len - 1] == '\n') {//verifica se a string nao esta vazia e se o ultimo caractere da string � uma nova linha
            pessoas[i].nome[len - 1] = '\0';
        }
        pessoas[i].numAmigos = 0;//incializa o numero de amigos
        pessoas[i].amigos = (int *)malloc(MAX * sizeof(int));  // aloca memoria para armazenar MAx, converte o ponteiro para int
    }

    // Leitura das amizades
    for (int i = 0; i < m; i++) {
        int x, y;
        fscanf(arquivoDados, " e %d %d", &x, &y);//l� os dados inteiros do arquivo com a fun��o fscanf
        x--;  // Ajusta para �ndice baseado em zero
        y--;  // Ajusta para �ndice baseado em zero
        pessoas[x].amigos[pessoas[x].numAmigos++] = y;//acessa a lista de amigos da pessoa e incrementa o numero de amigos da pessoa e adiciona a lista de amigos
        pessoas[y].amigos[pessoas[y].numAmigos++] = x;//acessa a lista de amigos da pessoa e incrementa o numero de amigos da pessoa e adiciona a lista de amigos
    }
    fclose(arquivoDados);//fecha o arquivo

    // imprimir a lista de amigos de cada pessoa
    printf("Lista de amigos:\n");
    for (int i = 0; i < n; i++) {
        printf("%s: ", pessoas[i].nome);//imprime o nome da pessoa
        for (int j = 0; j < pessoas[i].numAmigos; j++) {//itera sobre todos amigos da pessoa[i]
            printf("%s ", pessoas[pessoas[i].amigos[j]].nome);//acessa o id do amigo, o nome do amigo e imprime o nome do amigo
        }
        printf("\n");
    }

    // Encontrar e imprimir o maior clique
    maior_rede_concetada(pessoas, n);

    // Libera��o da mem�ria alocada
    for (int i = 0; i < n; i++) {
        free(pessoas[i].amigos);
    }

    return 0;
}


